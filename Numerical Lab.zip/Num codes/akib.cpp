#include<iostream>
#include<math.h>

using namespace std;
#define Es 0.0001


double f(double x)
{
	return x*x*x-x*x-1;
}

void bisection(double Xl, double Xu)
{
   ;
	if (f(Xl) * f(Xu) >= 0)
	{
		cout << "You have not assumed right a and b\n";
		return;
	}

	double c = Xl;
	while ((fabs(Xu-Xl)) >=Es)
	{

		c = (Xl+Xu)/2;

		if (f(c) == 0.0)
        {
           break;

        }



		else if (f(c)*f(Xl) < 0)
			Xl = c;
		else
			Xu = c;
	}
	cout << "The value of root is : " << c;
}


int main()
{

	double Xl=1,Xu=2;
	bisection(Xl,Xu);
	return 0;
}

