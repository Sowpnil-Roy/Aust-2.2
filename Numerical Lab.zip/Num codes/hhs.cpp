    rError=fabs((xupper-xlower)/xupper);
    while(rError>es)
    {
        rError=fabs((xupper-xlower)/xupper);

        x0=(xlower + xupper)/2;
        f0=f(x0);
        if(f1*f0<0)
        {

            xupper=x0;
            absError= abs(x0-xlower);
            rError=fabs((xupper-xlower)/xupper);
            printf("No of itr=%d\t x0=%lf\t AbsError=%lf\t RelativeError=%lf\n", i, x0, absError, rError);
        }
        else
        {

            xlower=x0;
            absError= abs(xupper-x0);
            rError=fabs((xupper-xlower)/xupper);
            printf("No of itr=%d\t x0=%lf\t AbsError=%lf\t RelativeError=%lf\n", i, x0, absError, rError);
        }
    }

}
