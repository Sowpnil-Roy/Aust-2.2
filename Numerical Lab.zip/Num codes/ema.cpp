#include <stdio.h>
#include <stdlib.h>
#include<math.h>
#define function(x) (x*x*x-x-1)
#define allowed_error 0.0001
int main()
{
    float x1,x2, error = 0,err=0,  x0,f0;
    int i= 1;
    printf("Enter the value of Xlower:\t");
    scanf("%f", &x1);
    printf("Enter the value of Xupper:\t");
    scanf("%f", &x2);
    printf("\n");
    if((function(x1) * function(x2)) > 0)\
    {
        printf("Invalid Intervals\n");
        exit(0);
    }
     printf("id\t Aproximate Root\t  Absolute error\t Relative error\t Change of Limit\t   \n");
    do
    {
        printf("%d\t %0.1f\t %0.1f\t %0.1f\t %0.1f\t", i++,x0,err,error,function(x0));

        x0=(x1+x2)/2;
        f0=function(x0);

        if(f0 == 0)
        {
            printf(" root=%f",x0);
        }
        else if(function(x1) * function(x0) < 0)
        {
            x2 = x0;
        }
        else
        {
            x1 = x0;
        }
        error = (fabs((x2-x1)/x2));
        err = ( x2- x1);
        printf("\n");

    }
    while(error > allowed_error);
    printf("\n\nApproximate root:\t%f\n",x0);

    return 0;
}
