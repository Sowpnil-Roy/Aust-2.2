#include<bits/stdc++.h>
using namespace std;

#define H 0.1
#define epsilon 0.000001

double F(double x)
{
    //return (x*x*x*x) - (10*x*x*x) + (35*x*x) - (50*x) + 24;
    return (2*x*x*x) - (6*x*x) + (2*x) + 1;
}

double ModifiedBisectionMethod(double a,double b)//lower limit & upper limit
{
    double x1,xr,x2;
    while(1)
    {
      x1=a;//lower limit
      x2=a+H;
      double F1=F(x1);
      double F2=F(x2);
      if(F1*F2<0)
      {
          while(fabs(x2-x1)>=epsilon)//absulate value
          {
            xr=(x1+x2)/2;//root
            if(F(xr)==0.0)
                break;
            else if(F(xr)*F(x1)<0)
                x2=xr;
            else
                x1=xr;
          }
          cout<<"ROOT : ";
          printf("%.3lf\n",xr);
      }
      if(x2<b)
      {
        a=x2;
        continue;
      }
      else
        break;
   }
}

int main()
{
    //ModifiedBisectionMethod(-1.05,6.05);
    ModifiedBisectionMethod(0.00,6.00);
    return 0;
}
