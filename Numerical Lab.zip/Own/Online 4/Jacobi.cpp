#include<bits/stdc++.h>
using namespace std;
int main()

{

    int n,i,j,k;
    cout<<"Enter the order of the matrix: ";
    cin>>n;


    double a[n+1][n+1],x[n+1],sum,temp[n+1],error,allowederror=0.00001,temperror;


//co-efficient input

    for(k=1; k<=n; k++)
    {
        for(j=1; j<=n+1; j++)
        {
            printf("Co-efficient of a[%d][%d] = ", k,j);
            cin>>a[k][j];

        }
    }


//initial
    for(i=1; i<=n; i++)
        x[i] =0;

//Jacobi
    do
    {
        temperror=0;
        for(i=1; i<=n; i++)
        {
            sum=0;
            for(j=1; j<=n; j++)
            {
                if(i!=j)
                {


                    {
                        sum+=a[i][j]*x[j];
                    }

                }

                temp[i]=(a[i][n+1]-sum)/a[i][i];
                error = fabs(x[i]-temp[i]);
                if(error>temperror)
                {
                    temperror=error;
                }
            }
            for (i=1; i<=n; i++)
            {
                x[i]=temp[i];
            }

        }}
        while(temperror>=allowederror);

//print
        for(i=1; i<=n; i++)
        {
            cout<<"x"<<i<<" = ";
            cout<<x[i]<<endl;

        }
    }




