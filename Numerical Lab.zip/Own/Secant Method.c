#include<stdio.h>
#include<conio.h>
#include<math.h>
#define e 0.001
#define f(x) x*x*x-4*x +1

void main()
{
    int i=0;
    float x0,x1,x2,f0,f1,f2;

    clrscr();
    printf("Enter the values of x0 and x1");
    scanf("%f%f",&x0,&x1);

    do{

        f0=f(x0);
        f1=f(x1);
        f2=
    }
}
