#include<iostream>
#include <math.h>
using namespace std;
double A[100] ;
int n ;
double horner(double x)
{

    int j=n;
    double b[j];
    b[j]=A[j];

    while(j>0)
    {
        b[j-1] = A[j-1]+b[j]*x;
        j--;
    }
    return b[j];

}

double func2(double x)
{
    return 2-x*x;

}

void fixedPoint(double x1,double Es)
{
    int iter=1;
    double x2=x1,oldRoot=0,absErr;
    cout<<"\n------------------------------------------------------------------------------" ;
    cout<<"\n\tIteration\t\tX1\t\tx2" ;
    cout<<"\n------------------------------------------------------------------------------\n" ;

    do
    {
        x2=func2(oldRoot);

        if(horner(x2)==0)
        {
            cout << "the root iss "<<x2<<endl;
            return;
        }
        cout<<"\t"<<iter++<<" \t\t\t "<<x1<<" \t\t "<<x2<<"\n" ;

        absErr=fabs(x2-oldRoot);
        oldRoot=x2;

        if(absErr<Es)
        {
            cout << "the root is "<<x2<<endl;
            return;
        }
    }

    while(absErr>Es);
}
int main()
{

    cout<<"ENTER THE TOTAL NO. OF POWER:::: " ;
    cin>>n ;
    int i ;
    for(i=0; i<n+1; i++)
    {
        cout<<"\tX^"<<i<<"::" ;
        cin>>A[i] ;
    }
    cout<<"\tTHE POLYNOMIAL IS :::: " ;
    for(i=n; i>=0; i--)
    {
        cout<<"  "<<A[i]<<"X^"<<i ;
        if(A[i]>=0)
        {
            cout<<"+" ;
        }
    }
    double x0;
    cout<<"\n\tINITIAL X1----> " ;
    cin>>x0 ;

    fixedPoint(x0,0.0001);
}
