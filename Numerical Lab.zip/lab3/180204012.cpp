#include<bits/stdc++.h>
#include<math.h>
using namespace std;
int A[100],n1;


double f(int poly[], int n, double x)
{
    double result = poly[0];
    for (int i=1; i<n; i++)
        result = result*x + poly[i];

    return result;
}

double g(int poly[],int order,double x)
{
    double value = 0;
    int i;
    for(i=0; i<order; i++)
    {
        value = value*x + (order-i)*poly[i];
    }
    return value;
}


double FixedPoint(double x)
{
    double xprev=x, gx;
    int i=0;
    int condition;

    for(int i=1;; i++)
    {
        x = f(A,n1+1,xprev);
        gx=g(A,n1,xprev);
        cout<<'\n'<<i<<"\t "<<x;
        if(abs(x-xprev)<=0.00000001)
            break;
        if(i>=2)
        {
            cout<<"Do not converge"<<'\n';
            break;
        }
        xprev = x;
    }
    return x;
    cout<<"Calculate the Condition number:";
    cin>>condition;
    if(condition>2)
    {
        cout<<"Then print f(x) is numerically unstable and stop";
    }

    else
    {
        cout<<"f(x)is numerically stable";
    }

}
int main()
{
    double Xo;
    int i;

    cout<<"ENTER THE TOTAL NO. OF POWER:::: ";
    cin>> n1;

    for( i=0; i<= n1; i++)
    {
        cout<<"\nx^"<<i<<"::";
        cin >> A[n1-i];
    }
    cout<<"\nTHE POLYNOMIAL IS ::: ";
    for(int i=0; i<=n1; i++)
    {
        if(A[i]==0)
            continue;
        cout<<"("<<A[i]<<")"<<"x^"<<(n1-i)<<"+";
    }
    A[n1-1]=0;
    cout << "\nINTIAL: Xo---->";
    cin >> Xo;
    cout<<"\nTHE POLYNOMIAL g(x) IS ::: ";
    for(int i=0; i<=n1; i++)
    {
        if(A[i]==0)
            continue;
        cout<<"("<<A[i]<<")"<<"x^"<<(n1-i)<<"+";
    }

    Xo = FixedPoint(Xo);
    cout << "\n Approximate root: "<< Xo ;
    return 0;
}
