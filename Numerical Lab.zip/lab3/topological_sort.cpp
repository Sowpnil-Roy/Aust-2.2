#include<bits//stdc++.h>
using namespace std;

vector<int> graph[50];
int indegree[50];
int status[50];
queue<int> bag;

void initstatus(int n)
{
    for (int i = 1; i <= n; i++)
        indegree[i] = 0;
    for (int i = 1; i <= n; i++)
        status[i] = 1;
}
void printgraph(int n)
{
    for(int i=1; i<=n; i++)
    {
        cout << "node " << i << " is Connected to :";
        for(int j=0; j<graph[i].size(); j++)
        {
            cout << "node " <<graph[i][j] << " ";
        }
        cout << endl;
    }
}

void inputgraph(int n, int e)
{
    initstatus(n);
    for (int i = 1; i <= e; i++)
    {
        int x, y;
        cin >> x >> y;
        indegree[y]++;
        graph[x].push_back(y);
    }
}

void topo(int n)
{
    int coun = 0;
    while (coun <= n)
    {
        coun++;
        for (int i = 1; i <= n; i++)
        {
            if (indegree[i] == 0 && status[i] == 1)
            {
                bag.push(i);
                status[i] = 2;
                for (int j = 0; j < graph[i].size(); j++)
                {
                    indegree[graph[i][j]]--;
                }
            }
        }
    }
}

int main()
{
    int e,n,source;
    cout << "Enter the numbers of edges : ";
    cin >> e;
    cout << endl;
    cout << "Enter the numbers of nodes : ";
    cin >> n;
    cout << endl;
    cout << "Enter edges : ";
    inputgraph(n,e);
    cout << endl;
    printgraph(n);
    cout << "topo :";
    topo(n);
    while(!bag.empty())
    {
        cout << bag.front() << "  ";
        bag.pop();

    }
    cout << endl;
    return 0;
}