#include<bits/stdc++.h>
#include<math.h>
using namespace std;
int A[100],n1;


double f(int poly[], int n, double x)
{
    double result = poly[0];
    for (int i=1; i<n; i++)
        result = result*x + poly[i];

    return result;
}


double secant(double x1,double x2)
{
    double fx1,fx2,i=0,x;
    cout<<"\n**************************************"<<'\n';
    cout<<"ITERATION X1 X2 X3 F(X)1 F(X)2"<<'\n';
    cout<<"**************************************"<<'\n';

    while(true)
    {
        i++;
        fx1 = f(A,n1+1,x1);
        fx2 = f(A,n1+1,x2);
        x = x2-(((x2-x1)*fx2)/(fx2-fx1));
        cout<<i<<"\t "<<x1<<" "<<x2<<" "<<x<<" "<<fx1<<"   "<<fx2<<'\n';
        if(abs(x2-x1)<=0.00009) break;
        x1=x2;
        x2=x;

    }
    return x;
}

int main()
{
    double Xo,X1,X2;
    int i;

    cout<<"ENTER THE TOTAL NO. OF POWER:::: ";
    cin>> n1;
    cout<<"\nEnter values of coefficients:\n";
    for( i=0; i<= n1; i++)
    {
        cout<<"\nx^"<<i<<"::";
        cin >> A[n1-i];
    }
    cout<<"\nTHE POLYNOMIAL IS ::: ";
    for(int i=0; i<=n1; i++)
        cout<<"("<<A[i]<<")"<<"x^"<<(n1-i)<<"+";
    cout << "\nINTIAL: Xo---->";
    cin >> X1>>X2;


    Xo = secant(X1,X2);
    cout << "\n Approximate root: "<< Xo ;
    return 0;
}
