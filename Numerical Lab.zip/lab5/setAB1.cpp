#include<bits/stdc++.h>
#include <time.h>
#include <unistd.h>
#include<conio.h>

using namespace std;

float B[20][20];
float n1,n2,r1,r2,r3,r4;


void guass_elimination(float A[20][20], int n)
{
    double time_spent = 0.0;

    clock_t begin = clock();

    cout<<endl<<"Starting of Execution Gauss Elimination method..."<<endl;
    float c,x[10],sum=0.0;
    for(int j=1; j<=n; j++)
    {
        for(int i=1; i<=n; i++)
        {
            if(i>j)
            {
                c=A[i][j]/A[j][j];
                for(int k=1; k<=n+1; k++)
                {
                    A[i][k]=A[i][k]-c*A[j][k];
                }
            }
        }
    }
    x[n]=A[n][n+1]/A[n][n];

    for(int i=n-1; i>=1; i--)
    {
        sum=0;
        for(int j=i+1; j<=n; j++)
        {
            sum=sum+A[i][j]*x[j];
        }
        x[i]=(A[i][n+1]-sum)/A[i][i];
    }
    cout<<"\nThe solution of linear equation is: "<<endl;
    for(int i=1; i<=n; i++)
    {
        printf("\nx[%d]=%f\n",i,x[i]);
    }
    cout<<endl<<"End of execution...."<<endl;

    clock_t end = clock();

    time_spent += (double)(end - begin) / CLOCKS_PER_SEC;

    cout<<"Running time for Gauss Elimination method is:"<< time_spent<<endl;

    printf("total number of flops for gauss jorden method for 3equations:");
    r1 = .5 * n1 * n1* n1;
    cout<<r1<<"\n";
    printf("total number of flops for gauss jorden method for 6equations:");
    r2 = .5 * n2*n2*n2;
    cout<<r2<<"\n";

}
float f1(float x,float y,float z)
{
    float a,b,c,d;
    a = B[1][1];
    b = B[1][2];
    c = B[1][3];
    d = B[1][4];
    x = (d - b*y - c*z)/a;
    return x;
}
float f2(float x,float y,float z)
{
    float a,b,c,d;
    a = B[2][1];
    b = B[2][2];
    c = B[2][3];
    d = B[2][4];
    y = (d - a*x - c*z)/b;
    return y;
}
float f3(float x,float y,float z)
{
    float a,b,c,d;
    a = B[3][1];
    b = B[3][2];
    c = B[3][3];
    d = B[3][4];
    z = (d - a*x - b*y)/c;
    return z;
}
void guass_seidal()
{
    double time_spent = 0.0;

    clock_t begin = clock();

    cout<<endl<<"Starting of Execution Gauss Seidal method...";

    float x0=0, y0=0, z0=0, x1, y1, z1, e1, e2, e3, e;
    int count=1;

    e=0.05;
    do
    {
        x1 = f1(x0,y0,z0);
        y1 = f2(x1,y0,z0);
        z1 = f3(x1,y1,z0);

        e1 = fabs(x0-x1);
        e2 = fabs(y0-y1);
        e3 = fabs(z0-z1);

        count++;

        x0 = x1;
        y0 = y1;
        z0 = z1;

    }
    while(e1>e && e2>e && e3>e);

    cout<<endl<<"The solution of linear equation is:"<<endl;
    cout<<"x[1]="<<x1<<endl;
    cout<<"x[2]="<<y1<<endl;
    cout<<"x[3]="<<z1<<endl;
    cout<<endl<<"End of execution...."<<endl;

    clock_t end = clock();

    time_spent += (double)(end - begin) / CLOCKS_PER_SEC;

    cout<<"Running time for Gauss Seidal method is:"<< time_spent<<endl;

      printf("total number of flops for gauss jorden method for 3equations:");
    r3 = n1 * n1 * n1* n1;
    cout<<r3<<"\n";
    printf("total number of flops for gauss jorden method for 6equations:");
    r4 = n2 * n2*n2*n2;
    cout<<r4<<"\n";
}

int main()
{
    int n;
    float X[20][20];
    cout<<"\nEnter the size of equation: ";
    cin>>n;

     printf("Enter the two size of n in the equations: ");
    cin>>n1>>n2;

    cout<<"\nEnter the elements of coefficient:\n\n";
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=(n+1); j++)
        {
            printf("X[%d][%d] : ", i,j);
            cin>>X[i][j];
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n+1;j++)
            B[i][j]=X[i][j];
    }

    guass_elimination(X,n);
    guass_seidal();

    getch();
    return 0;
}3

