#include<bits/stdc++.h>
#include <time.h>
#include <unistd.h>
#include<conio.h>

using namespace std;

float B[20][20];

void guass_jordan(float A[20][20], int n)
{

    cout<<endl<<"Starting of Execution Gauss Jordan method:"<<endl;
    float c,x[10];
    int count=0;
    for(int j=1; j<=n; j++)
    {
        for(int i=1; i<=n; i++)
        {
            if(i!=j)
            {
                c=A[i][j]/A[j][j];
                for(int k=1; k<=n+1; k++)
                {
                    A[i][k]=A[i][k]-c*A[j][k];
                }
                count++;
            }
        }
    }



    cout<<"\nThe solution of linear equation is: "<<endl;
    for(int i=1; i<=n; i++)
    {
        x[i]=A[i][n+1]/A[i][i];

    }
    cout<<"\n x="<<x[1]<<endl;
    cout<<"\n y="<<x[2]<<endl;
    cout<<"\n z="<<x[3]<<endl;




}
float f1(float x,float y,float z)
{
    float a,b,c,d;
    a = B[1][1];
    b = B[1][2];
    c = B[1][3];
    d = B[1][4];
    x = (d - b*y - c*z)/a;
    return x;
}
float f2(float x,float y,float z)
{
    float a,b,c,d;
    a = B[2][1];
    b = B[2][2];
    c = B[2][3];
    d = B[2][4];
    y = (d - a*x - c*z)/b;
    return y;
}
float f3(float x,float y,float z)
{
    float a,b,c,d;
    a = B[3][1];
    b = B[3][2];
    c = B[3][3];
    d = B[3][4];
    z = (d - a*x - b*y)/c;
    return z;
}
void guass_seidal()
{



    cout<<endl<<"Starting of Execution Gauss Seidal method:";

    float  x1, y1, z1, e1, e2, e3, x0,y0,z0,e;
    int count=1;

    e=0.005;
    do
    {
        x1 = f1(x0,y0,z0);
        y1 = f2(x1,y0,z0);
        z1 = f3(x1,y1,z0);

        e1 = fabs(x0-x1);
        e2 = fabs(y0-y1);
        e3 = fabs(z0-z1);

        count++;

        x0 = x1;
        y0 = y1;
        z0 = z1;

    }
    while(e1>e && e2>e && e3>e);


    cout<<endl<<"The solution of linear equation is:"<<endl;
    cout<<"x="<<x1<<endl;
    cout<<"y="<<y1<<endl;
    cout<<"z="<<z1<<endl;




    cout<<endl<<"Number of Iteration:"<<count<<endl;



}

int main()
{
    int n;
    float X[20][20];
    cout<<"\nEnter the size of equation: ";
    cin>>n;
    cout<<"\nEnter the elements of coefficient:\n\n";
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=(n+1); j++)
        {
            printf("X[%d][%d] : ", i,j);
            cin>>X[i][j];
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n+1;j++)
            B[i][j]=X[i][j];
    }

    guass_jordan(X,n);
    guass_seidal();

    cout<<"Table"<<endl;

    cout<<"Total Number of Flops when n=3:"<<endl;
    float p=0.5*n*n*n;
    float q=n*n*n*n;
    cout<<"Guass Jordan -> "<<p<<endl;
    cout<<"Guass Seidel -> "<<q<<endl;



    //int n;
    //float X[20][20];
    cout<<"\nEnter the size of equation: ";
    cin>>n;
    cout<<"\nEnter the elements of coefficient:\n\n";
    for(int i=1; i<=n; i++)
    {
        for(int j=1; j<=(n+1); j++)
        {
            printf("X[%d][%d] : ", i,j);
            cin>>X[i][j];
        }
    }
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n+1;j++)
            B[i][j]=X[i][j];
    }

    guass_jordan(X,n);
    guass_seidal();

    cout<<"Table"<<endl;

    cout<<"Total Number of Flops when n=3:"<<endl;
    float m=0.5*n*n*n;
    float r=n*n*n*n;
    cout<<"Guass Jordan -> "<<m<<endl;
    cout<<"Guass Seidel -> "<<r<<endl;




    getch();
    return 0;
}
