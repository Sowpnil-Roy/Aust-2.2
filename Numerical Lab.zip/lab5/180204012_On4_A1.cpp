#include<bits/stdc++.h>
#include<conio.h>
#include<time.h>
using namespace std;
#define SIZE 10
float a[SIZE][SIZE],x[SIZE],ratio;
int i,j,k,n, cont=0,cont2=0,temp;
float n1,n2,r1,r2,r3,r4;
float B[20][20];

void gaussJordan()
{
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n;j++)
        {
            if(i!=j)
            {
                ratio = a[j][i]/a[i][i];
                for(k=1;k<=n+1;k++)
                {
                    a[j][k] = a[j][k] - ratio*a[i][k];
                }
            }
        }
        cont++;
    }

    for(i=1;i<=n;i++)
    {
        x[i] = a[i][n+1]/a[i][i];
    }

    printf("Starting of Execution Gauss Jordan Method:");
    printf("\nThe solution of linear equation is:\n");
    for(i=1;i<=n;i++)
    {
        printf("x[%d] = %0.3f\n",i, x[i]);
    }
    printf("total number of flops for gauss jorden method for 3 equations: ");
    r1 = .5 * n1*n1*n1;
    cout<<r1<<"\n";
    printf("total number of flops for gauss jorden method for 6 equations: ");
    r2 = .5 * n2*n2*n2;
    cout<<r2<<"\n";
    printf("End of Execution.\n");
}

float f1(float x,float y,float z)
{
    float a,b,c,d;
    a = B[1][1];
    b = B[1][2];
    c = B[1][3];
    d = B[1][4];
    x = (d - b*y - c*z)/a;
    return x;
}
float f2(float x,float y,float z)
{
    float a,b,c,d;
    a = B[2][1];
    b = B[2][2];
    c = B[2][3];
    d = B[2][4];
    y = (d - a*x - c*z)/b;
    return y;
}
float f3(float x,float y,float z)
{
    float a,b,c,d;
    a = B[3][1];
    b = B[3][2];
    c = B[3][3];
    d = B[3][4];
    z = (d - a*x - b*y)/c;
    return z;
}
void guassSeidal()
{
    float x0=0, y0=0, z0=0, x1, y1, z1, e1, e2, e3, e;
    e=0.005;
    do
    {
        x1 = f1(x0,y0,z0);
        y1 = f2(x1,y0,z0);
        z1 = f3(x1,y1,z0);

        e1 = fabs((x0-x1)/x0);
        e2 = fabs((y0-y1)/y0);
        e3 = fabs((z0-z1)/z0);

        cont2++;

        x0 = x1;
        y0 = y1;
        z0 = z1;

    }
    while(e1>e && e2>e && e3>e);

    printf("Starting of Execution Gauss Seidal Method:");
    cout<<endl<<"The solution of linear equation is:"<<endl;
    cout<<"x[1]="<<x1<<endl;
    cout<<"x[2]="<<y1<<endl;
    cout<<"x[3]="<<z1<<endl;

    printf("total number of flops for gauss jorden method for 3 equations: ");
    r3 = n1 * n1*n1*n1;
    cout<<r3<<"\n";
    printf("total number of flops for gauss jorden method for 6 equations: ");
    r4 = n2 * n2*n2*n2;
    cout<<r4<<"\n";

    cout<<endl<<"End of execution...."<<endl;
}

int main()
{

    printf("Enter the size of the equations: ");
    scanf("%d", &n);

    printf("Enter the two size of n in the equations: ");
    cin>>n1>>n2;

    printf("Enter the elements of coefficients:\n");
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=n+1;j++)
        {
            printf("a[%d][%d] = ",i,j);
            scanf("%f", &a[i][j]);
        }
    }
     for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=n+1;j++)
            B[i][j]=a[i][j];
    }

double time_spent=0.0;
    clock_t t;
    clock_t begin = clock();
    gaussJordan();
    clock_t end = clock();
    time_spent+=(double)(end-begin)/CLOCKS_PER_SEC;
    printf("\nRunning Time for Gauss Jordan Method = %lf seconds\n", time_spent);
    printf("Number of iterations: %d", cont);

double time_spent2=0.0;
    clock_t begin1 = clock();
    guassSeidal();
    clock_t end1 = clock();
    time_spent2+=(double)(end1-begin1)/CLOCKS_PER_SEC;
    printf("\nRunning Time for Gauss Jordan Method = %lf seconds\n", time_spent);
    printf("Number of iterations: %d", cont2);

     getch();
    return 0;
}
