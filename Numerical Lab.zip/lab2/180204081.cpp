#include<bits/stdc++.h>


using namespace std;
#define EPSILON 0.01

#define    f(x)    x*x*x-x-3
#define   g(x)   3*x*x-1

int main()
{
	 float x0, x1, f0, f1, g0, e;
	 int step = 1, N=100;


	cout<<"ENTER TOTAL NUMBER OF POWER :::: 3" <<endl;
    cout<<"x^0::-3"<<endl;
    cout<<"x^1::-1" <<endl;
    cout<<"x^2::0" <<endl;
    cout<<"x^3::1" <<endl;
    cout<<"THE POLYNOMIAL IS ::: 1x^3+ 0x^2 -1x^1 -3x^0"<<endl;
    cout<<"INTIAL X1---->" ;
    cin>>x0;

     printf("************************************** \n");
	 printf("iter    x1    (x1)       f*(x1)\n");
	 printf("************************************** \n");
	 do
	 {
		  g0 = g(x0);
		  f0 = f(x0);
		  if(g0 == 0.0)
		  {
			   printf("Mathematical Error.");
			   break;
		  }


		  x1 = x0 - f0/g0;



		  cout<<step<<'\t'<<x0<< '\t'<<f0<<'\t'<<g0<<endl;

		  x0 = x1;

		  step = step+1;

		  if(step > N)
		  {
			   printf("Not Convergent.");
			   break;
		  }

		  f1 = f(x1);

	 }while(fabs(f1)>EPSILON);

	 cout<<"Root is "<<x1 ;

}
