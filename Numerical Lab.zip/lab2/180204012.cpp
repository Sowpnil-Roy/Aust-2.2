#include<bits/stdc++.h>
#include<math.h>
using namespace std;
double f(double x)
{
    return x*x*x-x-1;

}
double es=0.0001;

void bisection(double Xlower, double Xupper)
{

    if(f(Xlower)*f(Xupper)>=0)
    {

       cout << "You have not assumed right Xupper and Xlower\n";
        return;
    }

	double c = Xlower;
	while ((fabs(Xupper-Xlower)) >=es)
	{
        c = (Xlower+Xupper)/2;
        if (f(c) == 0.0)
        {
           break;

        }
        else if (f(c)*f(Xlower) < 0)
			Xlower = c;
		else
			Xupper = c;
	}
	cout << "Approximate root : " << c;
}

int main()
{
    double Xlower=1,Xupper=2;
	bisection(Xlower,Xupper);

	return 0;
}
